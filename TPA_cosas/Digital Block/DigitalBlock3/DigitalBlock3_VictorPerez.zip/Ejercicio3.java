package DigitalBlock3;

import java.util.Scanner;

public class Ejercicio3 {
	
	public static void main(String[] args) {
		
		/**  Creamos variable Scanner para escribir  **/
		Scanner sc = new Scanner(System.in);
		
		/**  Creamos un array de enteros  **/
		int[] miarray= {1,2,3,4,5,6,7,8,9};

		/**  Pedimos al usuario que nos indique el numero que desea buscar  **/
		System.out.println("Introduzca un numero para buscar: ");
		int x = sc.nextInt();
		
		/**  Llamamos a la funcion comprobar, para saber si el numero se encuentra en el array o no  **/
		System.out.println("El numero se encuentra en la posicion: " + (comprobar(miarray, x)-1) + " del array");
		
	}
	
	/**
	 * Funcion para saber si el numero que introducimos se encuentra en el array o no
	 * 
	 * Si no se encuentra, devolvemos 0
	 * 
	 * Si se encuentra, llamamos a la funcion para que nos indique la posicion en la que se encuentra
	 */
	public static int comprobar(int array[], int x) {
		if(x > array.length) {
			return 0;
		}else {
			return  buster(array,x, 0, array.length);
		}
	}
	
	/**
	 * Metodo que busca el numero indicado en el array y nos devuelve la posicion en la que se encuentra
	 */
	public static int buster (int array[],int x, int inicio, int fin) {
		/**  Caso base  **/
		if(inicio==fin) {
			return array[inicio];
		/**  Parte recursiva  **/
		}else {
			/**
			 * Creamos una variable rango, para saber en cuantas partes tenemos que dividir nuestra lista (evitando errores)
			 */
			int rango = fin - inicio;
			int tercio1 = inicio + (rango/3);
			int tercio2 = inicio + (2*rango/3);
			
			/**
			 * De esta manera nuestra lista se queda dividida en tres partes donde diferenciamos:
			 * 	el inicio 	(0/3)
			 * 	el tercio1 	(1/3)
			 * 	el tercio2 	(2/3)
			 * 	el final 	(3/3)
			 */

			/**
			 * Buscamos si nuestro numero coincide con alguna de las partes anteriores.
			 * Si esto pasara, devolvemos ese valor
			 * 
			 * [inicio, ..... , tercio1, ....., tercio2, ..... ,fin]
			 */
			if(x==tercio1) {
				return tercio1;
			}else if (x==tercio2) {
				return tercio2;
			}else if(x==fin) {
				return fin;	
			}else if (x==inicio) {
				return inicio;
				
			/**
			 * Si nuestro numero se encuentra entre el inicio y el primer tercio, llamamos a la funcion pasandole la lista correspondiente
			 */
			}else if(inicio < x && x < tercio1) {
				return buster(array, x, inicio, inicio+tercio1-1);	
		   /**
			* Si nuestro numero se encuentra entre el primer tercio y el segundo tercio, llamamos a la funcion pasandole la lista correspondiente
			*/
			}else if(x > tercio1 && tercio2 > x) {
				return buster(array, x, inicio+tercio1+1, fin-tercio1-1);	
		   /**
			* Si nuestro numero se encuentra entre el segundo tercio y el final, llamamos a la funcion pasandole la lista correspondiente
			*/
			}else {
				return buster(array, x, fin-tercio1+1, fin);
			}
		
		}
		
	}
	
}
