package DigitalBlock3;

public class Ejercicio1 {

	public static void main(String[] args) {
		/**
		 * Creamos un array llamado 'miLista'
		 */
		int[] miLista = {0,1,2,3,4,5,6,7,8,9};
		
		/**
		 * Llamamos a la funcion pares, a la cual le pasamos la lista, el inicio(0), el final(array-1) 
		 * y una variable para almacenar las numeros pares (iniciada en 0)
		 */
		System.out.println("Tenemos " + pares(miLista, 0, miLista.length-1, 0) +" elementos pares");
	}
	
	public static int pares(int[]array, int inicio, int fin, int par) {

		/**  Caso base  **/
		if (inicio == fin) {
			/**
			 * Si la posicion en la que estamos es par, incrementamos el valor par (de 0 a 1)
			 * En el caso contrario devolveriamos 0, ya que el elemento seria impar.
			 */
			if(array[inicio] %2 == 0) {
				par++;				
			}
			return par;
			
		/**  Parte recursiva  **/
		} else {
			/**
			 * Dividimos el array en dos mitades iguales
			 */
			int mitad = (fin+inicio)/2;
			
			/**
			 * Creamos dos variables, 'x' e 'y'. Estas seran las encargadas de almacenar el valor de 'par', 
			 * para posteriormete hacer la suma de los numeros pares que tenemos en cada una de las partes de la lista.
			 */
			int x = pares(array, inicio, mitad, par);
			int y = pares(array, mitad+1, fin, par);
			
			/**
			 * Sumamos las cantidades de numeros pares de cada una de las partes en la que hemos dividido la lista
			 */
			return x + y;
		}
	}

}
