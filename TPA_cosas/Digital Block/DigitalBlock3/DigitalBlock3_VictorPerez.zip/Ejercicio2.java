package DigitalBlock3;

import java.util.Scanner;

public class Ejercicio2 {
	public static void main(String[] args) {

		/**  Creamos variable Scanner para escribir  **/
		Scanner sc = new Scanner(System.in);

		/**  Creamos tres arrays, para poder demostrar que el emtodo funciona correctamente, 
		 *	 dos listas iguales y otra diferente a las anteriores 
		 **/
		int[] miLista1 = {1,2,3,4,5,6,7,8,9,10};
		int[] miLista2 = {1,2,3,4,5,6,7,8,9,10};
		int[] miLista3 = {1,3,5,7,9,2,4,6,8,10};
	
		System.out.println("Lista1 --> 1,2,3,4,5,6,7,8,9,10");
		System.out.println("Lista2 --> 1,2,3,4,5,6,7,8,9,10");
		System.out.println("Lista3 --> 1,3,5,7,9,2,4,6,8,10");
		System.out.println(" ");
		
		
		System.out.println("RECURSIVIDAD DIVISION (DyV) (Lista1 - Lista2)");
		if(comparacionesDyV(0, miLista1.length-1, miLista1, miLista2) == true) System.out.println("Listas ordenadas");
		else System.out.println("Listas desordenadas");
		System.out.println(" ");
		
		System.out.println("RECURSIVIDAD DIVISION (DyV) (Lista1 - Lista3)");
		if(comparacionesDyV(0, miLista1.length-1, miLista1, miLista3) == true) System.out.println("Listas ordenadas");
		else System.out.println("Listas desordenadas");
		System.out.println(" ");
		
		System.out.println("RECURSIVIDAD SUSTRACCION (Lista1 - Lista2)");
		if(comparacionesSus(miLista1.length-1, miLista1, miLista2) == true) System.out.println("Listas ordenadas");
		else System.out.println("Listas desordenadas");
		System.out.println(" ");
		
		System.out.println("RECURSIVIDAD SUSTRACCION (Lista1 - Lista3)");
		if(comparacionesSus(miLista1.length-1, miLista1, miLista3) == true) System.out.println("Listas ordenadas");
		else System.out.println("Listas desordenadas");
		System.out.println(" ");
		
	}



	public static boolean comparacionesSus(int fin, int miLista1[], int miLista2[]) {
		/**
		 * Si una vez recorrida la lista por completo, no hemos obtenido ningun false, devolveremos true.
		 * Si algunos de los elementos no coinciden, devolvemos false
		 * 
		 * Mientras que la lista no se haya recorrida entera y los elementos comparados hasta el momento coincidan,
		 * llamaremos a la funcion restandole uno al fin de la lista
		 */
		if(fin < 0) {
			return true;
		}else if(miLista1[fin] != miLista2[fin]) {
			return false;
		}else{
			return comparacionesSus(fin-1, miLista1, miLista2);
		}
	}

	
	public static boolean comparacionesDyV(int inicio, int fin, int miLista1[], int miLista2[]) {

		/**  Caso base  **/
		if (inicio == fin) {
			if(miLista1[inicio] == miLista2[inicio]) {
				return true; /**  Si los elementos son iguales devolvemos true  **/
			}else {
				return false; /** Si los elementos son diferentes devolvemos false  **/
			}

			/**  Parte recursiva  **/
		}else {

			/**
			 * Creamos una variable para dividir la lista en dos partes iguales
			 * 
			 * Creamos dos variable booleanas para saber si los elementos de las listas coinciden (true) o no (false)
			 */
			int mitad = (inicio+fin)/2;
			boolean x = comparacionesDyV(inicio, mitad, miLista1, miLista2);
			boolean y = comparacionesDyV(mitad+1, fin, miLista1, miLista2);

			/**
			 * Si en la primera mitad encontramos alguno diferente, devolveriamos false
			 */
			if(x != true) {
				return false;
			}
			/**
			 * Si en la segunda mitad encontramos alguno diferente, devolveriamos false
			 */
			if(y != true) {
				return false;
			}

			return true;	/**  Si todo esta bien (listas iguales), devolvemos true  **/
		}

	}
	
}
