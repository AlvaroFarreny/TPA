package DigitalBlock2;

public class ComprobacionQuickSort {

	public static void main(String[] args) {
		/**
		 * creamos un array con 10 elementos
		 */
		double[] misDatos = {4,8,3,3,7,6,2,10,2,4};
		
		/**
		 * Llamamos a la funcion quickSort y le pasamos como parametros 
		 * el array, la posicion inicial (0) y la final (array-1)
		 */
		Ordenacion.quickSort(misDatos,0,9);
		
		/**
		 * Aunque el enunciado decia que debiamos implementar la funcion
		 * de abajo, si le pasamos como parametros el 1 y el 10, el programa
		 * nos mostrara un error, ya que nuestro array va desde la posicion
		 * 0 hasta la 9, por lo que el 10 estaria fuera de esa dimension y
		 * produciria un error a la hora de ejecutarse
		 */
			//Ordenacion.quickSort(array,1,10);
		
		/**
		 * Creamos una variable con la longitud del array, y realizamos un bucle
		 * for con el objetivo de imprimir el array final una vez ordenado
		 * segun el metodo aplicado
		 */
		System.out.println("Primer apartado");
		int longitud = misDatos.length;
		for (int i=0;i<longitud;i++) {
			System.out.print(misDatos[i]+ "  ");
		}
		System.out.println("  ");
		
		
		System.out.println("Segundo apartado");

		/**
		 * creamos un array con 10 elementos
		 */
		int[] misDatos2 = {5,2,7,9,6,3,5,5,3,0};
		
		/**
		 * Llamamos a la funcion quickSortBis y le pasamos como parametros 
		 * el array, la posicion inicial (0) y la final (array-1)
		 */
		Ordenacion2.quickSortBis(misDatos2,0,9);
		
		/**
		 * Creamos una variable con la longitud del array, y realizamos un bucle
		 * for con el objetivo de imprimir el array final una vez ordenado
		 * segun el metodo aplicado
		 */
		int longitud2 = misDatos2.length;
		for (int i=0;i<longitud2;i++) {
			System.out.print(misDatos2[i]+ "  ");
		}
	}

}
