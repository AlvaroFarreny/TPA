package DigitalBlock2;

public class Ordenacion {	

	/**
	 * Esta funcion recibe como parametros el array, la posicion inicial (0) y la final (9)
	 */
	public static void quickSort(double[] array, int inicio, int fin) {
		/**
		 * Si la posicion inicial es mas peque�a que la final, entramos al bucle.
		 */
		if(inicio<fin) {
			/**
			 * Creamos una variable que trabajar como un pivote para distinguir los mayores
			 * y menores, pudiendo ordenar la lista de esa manera
			 */
			int pivote = pivotar(array, inicio, fin);
			/**
			 * La funcion se llama a si misma, pero ahora el array inicial se divide en dos partes:
			 * 	la de los numeros mas grandes que el pivote y otra con los menores.
			 */
			quickSort(array, inicio, pivote-1);
			quickSort(array, pivote+1, fin);

		}
	}
	
	public static int pivotar(double[] array, int inicio, int fin) {
		/**
		 * Creamos variable pivote, que almacena el valor del inicio de la lista que le pasemos
		 * 
		 * Ademas, una variable pivot, que almacenara el valor de la lista que este en la posicion
		 * de pivote (inicio)
		 */
		int pivote=inicio;
		double pivot = array[pivote];

		/**
		 * Si el inicio es mas peque�o que el fin, entramos al bucle
		 */
		if(inicio < fin) {
			/**
			 * Creamos bucle for:
			 * 		donde j es el inicio mas 1, asi no coincide con el pivot
			 * 		j tiene que ser siempre mas peque�o o igual que el fin
			 * 		j avanza de uno en uno, para poder comparar cada posicion de la lista
			 */
			for(int j = inicio+1; j<=fin; j++) {
				/**
				 * Si la posicion en la que estamos es mayor que el pivot, aumentamos la variable pivote en uno
				 */
				if(array[j] > pivot) {
					pivote++;
					/**
					 * Si la varible aumentada en uno (pivote), es diferente a la j, procedemos a hacer un intercambio
					 * de posiciones en la lista, moviendo el elemento mayor antes del pivote, y los menores despues 
					 * de este.
					 * De esta manera conseguimos nuestra lista no creciente.
					 */
					if (pivote!=j) {
						/**
						 * Creamos una variable para almacenar la posicion pivote
						 * Igualamos el valor de esa posicion con el valor de la posicion j
						 * Cambios el valor de la posicion j, igualandolo a la variable que contiene pivote almancenada
						 */
						double intercambio1 = array[pivote];
						array[pivote] = array[j];
						array[j] = intercambio1;
					}
				}
			}
			/**
			 * Creamos una variable para almacenar la posicion del inicio
			 * Igualamos el valor de esa posicion con el valor de la posicion pivote
			 * Cambios el valor de la posicion pivote, igualandolo a la variable que contiene inicio almancenada
			 * 
			 * Asi, movemos el pivote para que se quede en su sitio correcto
			 */
			double intercambio2 = array[inicio];
			array[inicio] = array[pivote];
			array[pivote] = intercambio2;
			
		}

		/**
		 * Devolvemos la pivote, que es donde se encuentra nuestro pivote
		 * En la funcion quickSort, se denomina pivote
		 */
		return pivote;
	}

}