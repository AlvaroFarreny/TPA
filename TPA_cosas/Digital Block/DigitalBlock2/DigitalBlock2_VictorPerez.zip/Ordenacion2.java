package DigitalBlock2;

public class Ordenacion2 {

	public static void quickSortBis(int[] array, int inicio, int fin) {
		/**
		 * Si la posicion inicial es mas peque�a que la final, entramos al bucle.
		 */
		if(inicio<fin) {
			/**
			 * Creamos una variable para poder almacenar la posicion del primer 
			 * y ultimo pivote que encontremos en nuestra lista
			 * 
			 * Rellenamos el array creado con el inicio
			 * 
			 */
			int[]posicionesPivote = {inicio,inicio};
			pivotarBis(array, inicio, fin, posicionesPivote);
			/**
			 * La funcion se llama a si misma, pero ahora el array inicial se divide en dos partes:
			 * la de los numeros mas grandes que el pivote y otra con los menores.
			 * 
			 */
			quickSortBis(array, inicio, posicionesPivote[0]);
			quickSortBis(array, posicionesPivote[1]+1, fin);
		}
	}
	
	public static void pivotarBis(int[] array, int inicio, int fin, int[] posicionesPivote) {
		/**
		 * Creamos una variable pivot, que sera una variable que utilizaremos como pivote. Esta sera el inicio de la lista
		 */
		int pivot = array[inicio];
		
		/**
		 * Creamos bucle for:
		 * 		donde j es el inicio mas 1, asi no coincide con el pivot
		 * 		j tiene que ser siempre mas peque�o o igual que el fin
		 * 		j avanza de uno en uno, para poder comparar cada posicion de la lista
		 */
		for(int j = inicio+1; j<=fin; j++) {
			/**
			 * Cuando encontramos un numero mas peque�o que el pivote, entramos al bucle
			 */
			if(array[j] < pivot) {
				posicionesPivote[0]++;
				/**
				 * Si la varible aumentada en uno (pivote), es diferente a la j, procedemos a hacer un intercambio
				 * de posiciones en la lista, moviendo el elemento mayor antes del pivote, y los menores despues 
				 * de este.
				 * De esta manera conseguimos nuestra lista no creciente.
				 */
				if(posicionesPivote[0] != j) {
					/**
					 * Creamos una variable para almacenar la posicion pivote
					 * Igualamos el valor de esa posicion con el valor de la posicion j
					 * Cambios el valor de la posicion j, igualandolo a la variable que contiene pivote almancenada
					 */
					int inter1 = array[posicionesPivote[0]];
					array[posicionesPivote[0]] = array[j];
					array[j] = inter1;
				}
			}
			
			/**
			 * Cuando encontramos un numero que es igual que el pivote, entramos al bucle
			 */
			if(array[j] == pivot) {
				if(posicionesPivote[1] == inicio) {
					int inter2 = array[posicionesPivote[1]];
					array[posicionesPivote[1]] = array[j];
					array[j] = inter2;
				}
			}
		}
		/**
		 * Creamos una variable para almacenar la posicion del inicio
		 * Igualamos el valor de esa posicion con el valor de la posicion pivote
		 * Cambios el valor de la posicion pivote, igualandolo a la variable que contiene inicio almancenada
		 * 
		 * Asi, movemos el pivote para que se quede en su sitio correcto
		 */
		int inter3 = array[inicio];
		array[inicio] = array[posicionesPivote[0]];
		array[posicionesPivote[0]] = inter3;
		
		/**
		 * Acabamos la funcion con el array posicionesPivote rellenado con los datos correctos
		 */
	}

}

